module solution {
	requires java.desktop;
}